<?php

$string['configtitle'] = 'Block title';
$string['cocoon_parallax_features:addinstance'] = 'Add a new [Cocoon] Parallax Features block';
$string['cocoon_parallax_features:myaddinstance'] = 'Add a new [Cocoon] Parallax Features block to Dashboard';
$string['pluginname'] = '[Cocoon] Parallax Features';
