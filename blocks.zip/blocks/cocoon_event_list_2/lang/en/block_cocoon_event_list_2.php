<?php
$string['cocoon_event_list_2:addinstance'] = 'Add a new block';
$string['cocoon_event_list_2:myaddinstance'] = 'Add a new block';
$string['pluginname'] = '[Cocoon] Event list 2';
