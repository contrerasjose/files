<?php
$string['pluginname'] = '[Cocoon] Hero 2';
$string['cocoon_hero_2'] = '[Cocoon] Hero 2';
$string['cocoon_hero_2:addinstance'] = 'Add a new Gallery block';
$string['cocoon_hero_2:myaddinstance'] = 'Add a new Gallery block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_button_text'] = 'Button text';
$string['config_button_link'] = 'Button link';
$string['config_image'] = 'Image';
