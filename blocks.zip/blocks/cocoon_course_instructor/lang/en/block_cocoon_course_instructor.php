<?php
$string['pluginname'] = '[Cocoon] Course Instructor';
$string['cocoon_course_instructor'] = '[Cocoon] Course Instructor';
$string['cocoon_course_instructor:addinstance'] = 'Add a new Course Instructor block';
$string['cocoon_course_instructor:myaddinstance'] = 'Add a new Course Instructor block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_name'] = 'Name';
$string['config_position'] = 'Position';
$string['config_students'] = 'Students';
$string['config_reviews'] = 'Reviews';
$string['config_courses'] = 'Courses';
$string['config_bio'] = 'Bio';
$string['config_rating'] = 'Rating';
