<?php

$string['cocoon_course_grid_4:addinstance'] = 'Add a [Cocoon] Featured Courses Masonry (Dark) block';
$string['cocoon_course_grid_4:myaddinstance'] = 'Add a [Cocoon] Featured Courses Masonry (Dark) to my moodle';
$string['pluginname'] = '[Cocoon] Featured Courses Masonry (Dark)';
$string['cocoon_course_grid_4'] = '[Cocoon] Featured Courses Masonry (Dark)';
$string['config_title'] = 'Title';
$string['config_subtitle'] = 'Subtitle';
$string['config_button_text'] = 'Button text';
$string['config_button_link'] = 'Button link';
$string['config_hover_text'] = 'Hover text';
$string['config_hover_accent'] = 'Hover accent';
